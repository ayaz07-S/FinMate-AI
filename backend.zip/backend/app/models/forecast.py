"""
Prophet ML forecasting logic with built-in uncertainty
"""
from prophet import Prophet
import pandas as pd
import numpy as np


def generate_three_scenarios(income_data, periods=90):
    """
    Generate 3 financial futures using Prophet's built-in uncertainty
    
    Args:
        income_data: List of dicts [{'date': '2024-01-01', 'income': 450}, ...]
        periods: Number of days to forecast (default 90)
    
    Returns:
        dict with 3 scenarios: pessimistic, base, optimistic
    """
    
    # Step 1: Prepare data for Prophet
    df = pd.DataFrame(income_data)
    df.columns = ['ds', 'y']  # Prophet requires these exact column names
    df['ds'] = pd.to_datetime(df['ds'])
    df = df.sort_values('ds')
    
    print(f"📊 Training on {len(df)} days of income data...")
    
    # Step 2: Configure and train Prophet model
    model = Prophet(
        yearly_seasonality=False,      # Gig workers don't follow yearly patterns
        weekly_seasonality=True,       # But they do have weekly patterns (weekends)
        daily_seasonality=False,
        interval_width=0.80,           # 80% confidence interval for scenarios
        changepoint_prior_scale=0.5,   # Flexibility in trend changes
        uncertainty_samples=1000       # Number of samples for uncertainty estimation
    )
    
    # Suppress Prophet's verbose output
    import logging
    logging.getLogger('prophet').setLevel(logging.WARNING)
    
    model.fit(df)
    print("✅ Model trained!")
    
    # Step 3: Generate forecast with built-in uncertainty
    future = model.make_future_dataframe(periods=periods)
    forecast = model.predict(future)
    
    # Get only future predictions (not historical)
    future_forecast = forecast.tail(periods)
    
    # Step 4: Use Prophet's built-in uncertainty bands directly
    # yhat = base prediction (median)
    # yhat_lower = lower bound (pessimistic - 10th percentile with 80% CI)
    # yhat_upper = upper bound (optimistic - 90th percentile with 80% CI)
    
    scenarios = {
        'dates': future_forecast['ds'].dt.strftime('%Y-%m-%d').tolist(),
        'pessimistic': future_forecast['yhat_lower'].clip(lower=0).tolist(),  # Bottom 10%
        'base': future_forecast['yhat'].clip(lower=0).tolist(),                # Median
        'optimistic': future_forecast['yhat_upper'].clip(lower=0).tolist()    # Top 90%
    }
    
    print("✅ Three scenarios generated using Prophet's built-in uncertainty!")
    print(f"   📉 Pessimistic: ₹{scenarios['pessimistic'][0]:.0f} → ₹{scenarios['pessimistic'][-1]:.0f}")
    print(f"   📊 Base: ₹{scenarios['base'][0]:.0f} → ₹{scenarios['base'][-1]:.0f}")
    print(f"   📈 Optimistic: ₹{scenarios['optimistic'][0]:.0f} → ₹{scenarios['optimistic'][-1]:.0f}")
    
    return scenarios


def quick_forecast_simple(income_data, periods=90):
    """
    Simpler fallback if Prophet is too slow or fails
    Uses linear regression + noise
    """
    df = pd.DataFrame(income_data)
    df['ds'] = pd.to_datetime(df['ds'])
    df = df.sort_values('ds')
    
    # Simple moving average
    mean_income = df['y'].mean()
    std_income = df['y'].std()
    
    # Generate future dates
    last_date = df['ds'].iloc[-1]
    future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=periods)
    
    # Simple scenarios with noise
    np.random.seed(42)
    base_values = np.random.normal(mean_income, std_income * 0.3, periods)
    
    scenarios = {
        'dates': future_dates.strftime('%Y-%m-%d').tolist(),
        'pessimistic': (base_values * 0.7).tolist(),
        'base': base_values.tolist(),
        'optimistic': (base_values * 1.3).tolist()
    }
    
    return scenarios