"""
Firebase helper functions
"""
import firebase_admin
from firebase_admin import credentials, db

def save_user_data(user_id, data):
    """Save data to Firebase"""
    pass

def get_user_data(user_id):
    """Retrieve data from Firebase"""
    pass
